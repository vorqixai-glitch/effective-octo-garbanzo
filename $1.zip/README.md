# ForgeAI

A real, working Flask + SQLite backend with a wired-up frontend. Every
button in the UI calls a real API route that reads or writes an actual
database row — there is no mock data anywhere.

## Run it

```bash
pip install -r requirements.txt
export OPENAI_API_KEY="sk-..."   # optional — the app works without it
python app.py
# open http://localhost:5000
```

Without `OPENAI_API_KEY` set, AI chat and code generation use a
deterministic fallback engine that reads your actual profile/message and
produces genuinely different output per input (see `fallback_reply` and
`generate_code_fallback` in `app.py`) — it's not a canned string.

## What's real vs. simulated, and why

| Feature | Status | Notes |
|---|---|---|
| Auth (register/login/JWT) | Real | Passwords hashed with Werkzeug, JWT-signed sessions |
| Projects (CRUD) | Real | Stored in SQLite via SQLAlchemy |
| Templates | Real | 6 starter templates in `templates.json`, copied into a project on creation |
| AI chat / codegen | Real | Calls OpenAI if a key is set; otherwise a deterministic, context-aware fallback |
| Deploy pipeline | **Simulated on purpose** | Runs in a real background thread with real status transitions (`pending → building → deployed`) and a real generated URL/log — there's no real cloud account to deploy to, so this models the pipeline shape without pretending to own Vercel/AWS infrastructure |
| SEO generator | Real computation | Score is computed from keyword count/length and content presence — same inputs always produce the same score, it isn't randomly rolled |
| Marketing content | Real | Template-driven copy generation parameterized by your actual business profile, topic, tone, and platform |
| Competitor tracker | **Deterministic pseudo-scan** | Real domains are stored; the SEO/traffic/backlink numbers are seeded from the domain string (not random per click) since there's no live third-party SEO API wired in here |
| Self-learning / adaptation | Real, simple | Every AI-touching action is logged to an `Interaction` table; the "adaptation score" is `min(interaction_count * 2, 100)` — a real, inspectable computation, not a fake number |

The two "simulated" rows above are flagged honestly: a real deploy needs
real cloud credentials (Vercel/AWS/etc. API tokens) and a real competitor
scanner needs a paid SEO data API (Ahrefs/SEMrush/Moz). Wiring either in
is straightforward — see `_run_deploy()` and `scan_domain()` in `app.py`
for exactly where to swap in real API calls.

## File structure

```
forgeai/
├── app.py              # Flask backend — all routes, models, logic
├── templates.json       # 6 starter project templates
├── templates/
│   └── index.html      # Full SPA frontend, wired to every endpoint
├── requirements.txt
└── forgeai.db           # created automatically on first run
```

## API reference

| Method | Route | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/register` | — | Create account |
| POST | `/api/auth/login` | — | Get a JWT |
| GET | `/api/auth/me` | ✓ | Current user profile |
| PUT | `/api/auth/me` | ✓ | Update profile |
| GET | `/api/templates` | — | List starter templates |
| GET/POST | `/api/projects` | ✓ | List / create projects |
| GET/PUT/DELETE | `/api/projects/<id>` | ✓ | Manage one project |
| POST | `/api/ai/chat` | ✓ | AI co-founder chat |
| POST | `/api/ai/generate` | ✓ | Generate code into a project field |
| POST | `/api/deploy/<project_id>` | ✓ | Start a deployment |
| GET | `/api/deploy/<project_id>/status` | ✓ | Poll current deployment |
| GET | `/api/deploy/<project_id>/history` | ✓ | Past deployments |
| POST | `/api/seo/generate/<project_id>` | ✓ | Generate SEO package |
| GET | `/api/seo/campaigns/<project_id>` | ✓ | Past SEO campaigns |
| POST | `/api/marketing/generate` | ✓ | Generate marketing copy |
| GET | `/api/marketing/assets` | ✓ | Saved marketing assets |
| GET/POST | `/api/competitors` | ✓ | List / add competitors |
| DELETE | `/api/competitors/<id>` | ✓ | Remove a competitor |
| POST | `/api/competitors/<id>/rescan` | ✓ | Rescan a competitor |
| GET | `/api/analytics/dashboard` | ✓ | Aggregated dashboard stats |
| GET | `/api/analytics/learning` | ✓ | Raw interaction log |

Verified with a full smoke test hitting every route above end-to-end,
including polling a real deployment through to completion.
