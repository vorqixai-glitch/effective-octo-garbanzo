import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "var(--bg-base)",
        foreground: "var(--text-primary)",
        card: "var(--bg-panel)",
        "card-foreground": "var(--text-primary)",
        primary: "var(--accent-primary)",
        "primary-foreground": "var(--bg-base)",
        secondary: "var(--bg-elevated)",
        "secondary-foreground": "var(--text-primary)",
        muted: "var(--bg-surface)",
        "muted-foreground": "var(--text-muted)",
        border: "var(--border-default)",
        input: "var(--bg-panel)",
        ring: "var(--accent-primary)",
        destructive: "var(--state-error)",
        success: "var(--state-success)",
        warning: "var(--state-warning)",
      },
      fontFamily: {
        sans: ["var(--font-geist-sans)", "system-ui", "sans-serif"],
        mono: ["var(--font-geist-mono)", "monospace"],
      },
      borderRadius: {
        sm: "6px",
        md: "8px",
        lg: "12px",
      },
      fontSize: {
        "2xs": "11px",
      },
      spacing: {
        "18": "4.5rem",
        "22": "5.5rem",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;
