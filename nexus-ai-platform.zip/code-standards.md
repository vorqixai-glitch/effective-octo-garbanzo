# Code Standards

## General

- Keep modules small and single-purpose
- Fix root causes, do not layer workarounds
- Do not mix unrelated concerns in one component or route
- Every component must be typed with explicit interfaces

## TypeScript

- Strict mode required throughout
- Avoid `any` — use `unknown` with type guards at boundaries
- Validate all external API responses with Zod schemas
- Use discriminated unions for state machines

## Next.js

- Default to Server Components
- Add `'use client'` only when browser interactivity requires it
- Route handlers focused on single responsibility
- API routes in `app/api/` following REST conventions

## Styling

- Use CSS custom property tokens — no hardcoded hex values
- Tailwind arbitrary values only for one-offs
- All spacing follows 4px grid system
- No inline styles except for dynamic values

## API Routes

- Validate and parse request input with Zod before any logic
- Enforce auth middleware before any mutation
- Return consistent response shapes: `{ success: boolean, data?: T, error?: string }`
- All external API calls wrapped in try/catch with proper error mapping

## Data and Storage

- Metadata in SQLite via Prisma
- Large generated content stored as files, referenced by path in DB
- API keys encrypted with AES-256-GCM, key from env
- Never log or expose API keys

## File Organization

- `app/(dashboard)/` — Protected dashboard pages
- `app/api/` — API route handlers
- `components/ui/` — shadcn/ui components (protected)
- `components/custom/` — NEXUS-specific components
- `lib/` — Utilities, auth, API clients, constants
- `hooks/` — Custom React hooks
- `types/` — Shared TypeScript definitions
- `prisma/` — Schema and migrations
