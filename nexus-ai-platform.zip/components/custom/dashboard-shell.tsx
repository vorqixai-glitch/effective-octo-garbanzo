"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import {
  LayoutDashboard,
  Sparkles,
  Globe,
  PenTool,
  Target,
  Film,
  Globe2,
  Calendar,
  BarChart3,
  FolderOpen,
  Settings,
  LogOut,
  ChevronRight,
} from "lucide-react";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/generator", label: "AI Generator", icon: Sparkles },
  { href: "/social", label: "Social Hub", icon: Globe },
  { href: "/composer", label: "Composer", icon: PenTool },
  { href: "/ads", label: "Ad Studio", icon: Target },
  { href: "/video", label: "Video Studio", icon: Film },
  { href: "/website", label: "Website Builder", icon: Globe2 },
  { href: "/schedule", label: "Scheduler", icon: Calendar },
  { href: "/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/projects", label: "Projects", icon: FolderOpen },
];

interface DashboardShellProps {
  children: React.ReactNode;
  user: { name?: string | null; email?: string | null };
}

export function DashboardShell({ children, user }: DashboardShellProps) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="flex h-screen bg-[var(--bg-base)]">
      {/* Sidebar */}
      <aside
        className={`flex flex-col border-r border-[var(--border-default)] bg-[var(--bg-surface)] transition-all duration-200 ${
          collapsed ? "w-16" : "w-56"
        }`}
      >
        {/* Logo */}
        <div className="flex h-14 items-center gap-3 border-b border-[var(--border-default)] px-4">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-[var(--accent-primary)] text-[var(--bg-base)] font-bold text-sm">
            N
          </div>
          {!collapsed && (
            <div className="flex items-center gap-1">
              <span className="text-sm font-semibold text-[var(--text-primary)]">NEXUS</span>
              <span className="text-2xs font-medium text-[var(--text-muted)]">AI</span>
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-3 px-2">
          <div className="space-y-0.5">
            {navItems.map((item) => {
              const isActive = pathname === item.href;
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors ${
                    isActive
                      ? "bg-[var(--accent-primary)]/10 text-[var(--accent-primary)]"
                      : "text-[var(--text-secondary)] hover:bg-[var(--bg-elevated)] hover:text-[var(--text-primary)]"
                  }`}
                >
                  <Icon className="h-4 w-4 shrink-0" strokeWidth={1.5} />
                  {!collapsed && <span className="truncate">{item.label}</span>}
                  {isActive && !collapsed && (
                    <ChevronRight className="ml-auto h-3.5 w-3.5 shrink-0 opacity-60" />
                  )}
                </Link>
              );
            })}
          </div>
        </nav>

        {/* Bottom */}
        <div className="border-t border-[var(--border-default)] p-2">
          <Link
            href="/settings"
            className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors ${
              pathname === "/settings"
                ? "bg-[var(--accent-primary)]/10 text-[var(--accent-primary)]"
                : "text-[var(--text-secondary)] hover:bg-[var(--bg-elevated)] hover:text-[var(--text-primary)]"
            }`}
          >
            <Settings className="h-4 w-4 shrink-0" strokeWidth={1.5} />
            {!collapsed && <span>Settings</span>}
          </Link>
          <button
            onClick={() => signOut({ callbackUrl: "/login" })}
            className="flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm text-[var(--text-secondary)] transition-colors hover:bg-[var(--bg-elevated)] hover:text-[var(--text-primary)]"
          >
            <LogOut className="h-4 w-4 shrink-0" strokeWidth={1.5} />
            {!collapsed && <span>Sign Out</span>}
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex flex-1 flex-col min-w-0">
        {/* Top bar */}
        <header className="flex h-14 items-center justify-between border-b border-[var(--border-default)] bg-[var(--bg-surface)] px-6">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setCollapsed(!collapsed)}
              className="rounded-md p-1.5 text-[var(--text-muted)] hover:bg-[var(--bg-elevated)] hover:text-[var(--text-primary)]"
            >
              <ChevronRight className={`h-4 w-4 transition-transform ${collapsed ? "rotate-180" : ""}`} />
            </button>
            <div className="flex items-center gap-2">
              <span className="text-2xs font-medium uppercase tracking-wider text-[var(--text-muted)]">
                {pathname.split("/")[1] || "Dashboard"}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-[var(--state-success)]" />
              <span className="text-2xs text-[var(--text-muted)]">All systems operational</span>
            </div>
            <div className="h-6 w-px bg-[var(--border-default)]" />
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-md bg-[var(--bg-elevated)] text-xs font-medium text-[var(--text-primary)]">
                {user.name?.charAt(0).toUpperCase() || "U"}
              </div>
              <span className="text-sm text-[var(--text-secondary)]">{user.name || user.email}</span>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
    </div>
  );
}
