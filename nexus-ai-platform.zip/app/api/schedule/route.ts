import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { z } from "zod";

const scheduleSchema = z.object({
  platform: z.string(),
  content: z.string().min(1),
  hashtags: z.string().optional(),
  scheduledAt: z.string().datetime(),
});

export async function GET(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const posts = await db.scheduledPost.findMany({
      where: { userId: session.user.id },
      orderBy: { scheduledAt: "asc" },
    });

    return NextResponse.json({ success: true, data: posts });
  } catch (err) {
    console.error("Get schedule error:", err);
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const parsed = scheduleSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ success: false, error: "Invalid input" }, { status: 400 });
    }

    const post = await db.scheduledPost.create({
      data: {
        userId: session.user.id,
        platform: parsed.data.platform,
        content: parsed.data.content,
        hashtags: parsed.data.hashtags || null,
        scheduledAt: new Date(parsed.data.scheduledAt),
      },
    });

    return NextResponse.json({ success: true, data: post }, { status: 201 });
  } catch (err) {
    console.error("Create schedule error:", err);
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 });
  }
}
