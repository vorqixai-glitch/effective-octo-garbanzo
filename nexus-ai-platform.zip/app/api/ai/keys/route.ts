import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { encrypt } from "@/lib/encryption";
import { z } from "zod";

const keySchema = z.object({
  provider: z.string(),
  key: z.string().min(1),
});

export async function GET(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const keys = await db.apiKey.findMany({
      where: { userId: session.user.id },
      select: { provider: true, isActive: true, createdAt: true },
    });

    return NextResponse.json({ success: true, data: keys });
  } catch (err) {
    console.error("Get keys error:", err);
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const parsed = keySchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ success: false, error: "Invalid input" }, { status: 400 });
    }

    const encrypted = encrypt(parsed.data.key);

    await db.apiKey.upsert({
      where: {
        userId_provider: {
          userId: session.user.id,
          provider: parsed.data.provider,
        },
      },
      update: { keyEncrypted: encrypted, isActive: true },
      create: {
        userId: session.user.id,
        provider: parsed.data.provider,
        keyEncrypted: encrypted,
      },
    });

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Save key error:", err);
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const provider = searchParams.get("provider");
    if (!provider) {
      return NextResponse.json({ success: false, error: "Provider required" }, { status: 400 });
    }

    await db.apiKey.deleteMany({
      where: { userId: session.user.id, provider },
    });

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Delete key error:", err);
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 });
  }
}
