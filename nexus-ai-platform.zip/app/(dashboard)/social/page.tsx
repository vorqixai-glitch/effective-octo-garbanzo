"use client";

import { useState, useEffect } from "react";
import { Globe, Link2, Unlink } from "lucide-react";

const allPlatforms = [
  { id: "instagram", name: "Instagram", icon: "📸", color: "#E4405F" },
  { id: "twitter", name: "Twitter/X", icon: "🐦", color: "#1a1a1a" },
  { id: "linkedin", name: "LinkedIn", icon: "💼", color: "#0A66C2" },
  { id: "tiktok", name: "TikTok", icon: "🎵", color: "#000000" },
  { id: "youtube", name: "YouTube", icon: "▶️", color: "#FF0000" },
  { id: "facebook", name: "Facebook", icon: "👥", color: "#1877F2" },
  { id: "pinterest", name: "Pinterest", icon: "📌", color: "#BD081C" },
  { id: "threads", name: "Threads", icon: "🧵", color: "#000000" },
  { id: "snapchat", name: "Snapchat", icon: "👻", color: "#FFFC00" },
  { id: "reddit", name: "Reddit", icon: "🔴", color: "#FF4500" },
];

export default function SocialPage() {
  const [connected, setConnected] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/platforms")
      .then((r) => r.json())
      .then((data) => {
        if (data.success) {
          setConnected(data.data.filter((p: any) => p.isConnected).map((p: any) => p.platform));
        }
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center text-[var(--text-muted)]">
        <Globe className="h-6 w-6 animate-pulse" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-[var(--text-primary)]">Social Hub</h1>
        <p className="text-sm text-[var(--text-secondary)]">Connect and manage your social platforms</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {allPlatforms.map((platform) => {
          const isConnected = connected.includes(platform.id);
          return (
            <div
              key={platform.id}
              className="rounded-md border border-[var(--border-default)] bg-[var(--bg-surface)] p-5 transition-colors hover:border-[var(--border-hover)]"
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl">{platform.icon}</span>
                <div className="flex-1">
                  <h3 className="text-sm font-medium text-[var(--text-primary)]">{platform.name}</h3>
                  <p className="text-2xs text-[var(--text-muted)]">
                    {isConnected ? "Connected" : "Not connected"}
                  </p>
                </div>
                <div
                  className={`h-2 w-2 rounded-full ${isConnected ? "bg-[var(--state-success)]" : "bg-[var(--text-muted)]"}`}
                />
              </div>
              <div className="mt-4">
                <button
                  onClick={() => alert(`OAuth flow for ${platform.name} would open here. Configure ${platform.id.toUpperCase()}_CLIENT_ID in .env.local`)}
                  className={`flex w-full items-center justify-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                    isConnected
                      ? "border border-[var(--border-default)] bg-[var(--bg-elevated)] text-[var(--text-secondary)] hover:text-[var(--state-error)]"
                      : "bg-[var(--accent-primary)] text-[var(--bg-base)] hover:opacity-90"
                  }`}
                >
                  {isConnected ? <Unlink className="h-3.5 w-3.5" /> : <Link2 className="h-3.5 w-3.5" />}
                  {isConnected ? "Disconnect" : "Connect"}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
