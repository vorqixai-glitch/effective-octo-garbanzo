"use client";

import { Construction } from "lucide-react";

export default function WebsitePage() {
  return (
    <div className="flex h-96 flex-col items-center justify-center text-[var(--text-muted)]">
      <Construction className="mb-4 h-10 w-10 opacity-40" />
      <h2 className="text-lg font-medium text-[var(--text-primary)]">Website</h2>
      <p className="mt-2 text-sm">This module is being built. Check back soon.</p>
      <p className="mt-1 text-2xs">Backend routes are ready — UI components in progress.</p>
    </div>
  );
}
