"use client";

import { useState, useEffect } from "react";
import { Key, Check, X, Loader2 } from "lucide-react";

const providers = [
  { id: "claude", name: "Claude (Anthropic)", env: "ANTHROPIC_API_KEY" },
  { id: "kimi", name: "Kimi (Moonshot AI)", env: "MOONSHOT_API_KEY" },
  { id: "gemini", name: "Gemini (Google)", env: "GOOGLE_AI_API_KEY" },
  { id: "grok", name: "Grok (xAI)", env: "XAI_API_KEY" },
  { id: "gpt", name: "GPT (OpenAI)", env: "OPENAI_API_KEY" },
  { id: "llama", name: "Llama (Groq)", env: "GROQ_API_KEY" },
];

export default function SettingsPage() {
  const [keys, setKeys] = useState<Record<string, boolean>>({});
  const [inputKey, setInputKey] = useState("");
  const [selectedProvider, setSelectedProvider] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch("/api/ai/keys")
      .then((r) => r.json())
      .then((data) => {
        if (data.success) {
          const map: Record<string, boolean> = {};
          data.data.forEach((k: any) => {
            map[k.provider] = k.isActive;
          });
          setKeys(map);
        }
      });
  }, []);

  async function saveKey() {
    if (!selectedProvider || !inputKey.trim()) return;
    setSaving(true);
    setMessage("");

    try {
      const res = await fetch("/api/ai/keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ provider: selectedProvider, key: inputKey }),
      });

      const data = await res.json();
      if (data.success) {
        setKeys((prev) => ({ ...prev, [selectedProvider]: true }));
        setInputKey("");
        setMessage("API key saved successfully");
      } else {
        setMessage(data.error || "Failed to save key");
      }
    } catch {
      setMessage("Network error");
    } finally {
      setSaving(false);
    }
  }

  async function deleteKey(provider: string) {
    try {
      const res = await fetch(`/api/ai/keys?provider=${provider}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        setKeys((prev) => {
          const next = { ...prev };
          delete next[provider];
          return next;
        });
      }
    } catch {
      setMessage("Failed to delete key");
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-[var(--text-primary)]">Settings</h1>
        <p className="text-sm text-[var(--text-secondary)]">Manage API keys and platform configuration</p>
      </div>

      {/* API Keys */}
      <div className="rounded-md border border-[var(--border-default)] bg-[var(--bg-surface)] p-5">
        <div className="mb-5 flex items-center gap-2">
          <Key className="h-4 w-4 text-[var(--accent-primary)]" />
          <h2 className="text-sm font-medium text-[var(--text-primary)]">AI Provider API Keys</h2>
        </div>

        <div className="space-y-3">
          {providers.map((provider) => (
            <div
              key={provider.id}
              className="flex items-center justify-between rounded-md border border-[var(--border-default)] bg-[var(--bg-elevated)] px-4 py-3"
            >
              <div>
                <p className="text-sm font-medium text-[var(--text-primary)]">{provider.name}</p>
                <p className="text-2xs text-[var(--text-muted)]">{provider.env}</p>
              </div>
              <div className="flex items-center gap-3">
                {keys[provider.id] ? (
                  <>
                    <span className="flex items-center gap-1 text-2xs text-[var(--state-success)]">
                      <Check className="h-3 w-3" /> Active
                    </span>
                    <button
                      onClick={() => deleteKey(provider.id)}
                      className="rounded-md p-1 text-[var(--text-muted)] hover:text-[var(--state-error)]"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </>
                ) : (
                  <span className="text-2xs text-[var(--text-muted)]">Not configured</span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Add Key */}
        <div className="mt-5 rounded-md border border-[var(--border-default)] bg-[var(--bg-elevated)] p-4">
          <h3 className="mb-3 text-sm font-medium text-[var(--text-primary)]">Add API Key</h3>
          <div className="flex gap-3">
            <select
              value={selectedProvider}
              onChange={(e) => setSelectedProvider(e.target.value)}
              className="rounded-md border border-[var(--border-default)] bg-[var(--bg-surface)] px-3 py-2 text-sm text-[var(--text-primary)] outline-none focus:border-[var(--accent-primary)]"
            >
              <option value="">Select provider</option>
              {providers.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
            <input
              type="password"
              value={inputKey}
              onChange={(e) => setInputKey(e.target.value)}
              placeholder="Paste API key"
              className="flex-1 rounded-md border border-[var(--border-default)] bg-[var(--bg-surface)] px-3 py-2 text-sm text-[var(--text-primary)] outline-none placeholder:text-[var(--text-muted)] focus:border-[var(--accent-primary)]"
            />
            <button
              onClick={saveKey}
              disabled={saving || !selectedProvider || !inputKey.trim()}
              className="rounded-md bg-[var(--accent-primary)] px-4 py-2 text-sm font-semibold text-[var(--bg-base)] transition-opacity hover:opacity-90 disabled:opacity-40"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}
            </button>
          </div>
          {message && (
            <p className={`mt-2 text-2xs ${message.includes("success") ? "text-[var(--state-success)]" : "text-[var(--state-error)]"}`}>
              {message}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
