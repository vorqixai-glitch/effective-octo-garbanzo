"use client";

import { useState } from "react";
import { Sparkles, Copy, Save, Send, Loader2 } from "lucide-react";

const contentTypes = [
  "social-post", "blog-article", "ad-copy", "email",
  "video-script", "website-copy", "product-desc", "seo-content",
  "press-release", "whitepaper",
];

const tones = ["professional", "casual", "humorous", "persuasive", "informative", "inspirational", "technical", "storytelling"];

const platforms = ["instagram", "twitter", "linkedin", "tiktok", "youtube", "facebook", "pinterest", "threads", "newsletter"];

const aiProviders = [
  { id: "claude", name: "Claude", color: "#c8a45c" },
  { id: "kimi", name: "Kimi", color: "#5c8aa4" },
  { id: "gemini", name: "Gemini", color: "#8a5cc8" },
  { id: "grok", name: "Grok", color: "#c85c5c" },
  { id: "gpt", name: "GPT", color: "#5cc88a" },
  { id: "llama", name: "Llama", color: "#c8a45c" },
];

export default function GeneratorPage() {
  const [selectedProviders, setSelectedProviders] = useState<string[]>(["claude"]);
  const [contentType, setContentType] = useState("social-post");
  const [tone, setTone] = useState("professional");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(["instagram"]);
  const [prompt, setPrompt] = useState("");
  const [keywords, setKeywords] = useState("");
  const [length, setLength] = useState("medium");
  const [generated, setGenerated] = useState<Record<string, string> | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleGenerate() {
    if (!prompt.trim()) return;
    setLoading(true);
    setError("");
    setGenerated(null);

    try {
      const res = await fetch("/api/ai/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          providers: selectedProviders,
          prompt,
          type: contentType,
          tone,
          length,
          keywords,
          platforms: selectedPlatforms,
        }),
      });

      const data = await res.json();
      if (!data.success) {
        setError(data.error || "Generation failed");
      } else {
        setGenerated(data.data.results);
      }
    } catch {
      setError("Network error");
    } finally {
      setLoading(false);
    }
  }

  function toggleProvider(id: string) {
    setSelectedProviders((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
    );
  }

  function togglePlatform(id: string) {
    setSelectedPlatforms((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-[var(--text-primary)]">AI Generator</h1>
        <p className="text-sm text-[var(--text-secondary)]">Generate content using multiple AI providers</p>
      </div>

      {/* Provider Selection */}
      <div className="rounded-md border border-[var(--border-default)] bg-[var(--bg-surface)] p-5">
        <h2 className="mb-4 text-sm font-medium text-[var(--text-primary)]">AI Providers</h2>
        <div className="flex flex-wrap gap-2">
          {aiProviders.map((provider) => (
            <button
              key={provider.id}
              onClick={() => toggleProvider(provider.id)}
              className={`flex items-center gap-2 rounded-md border px-3 py-2 text-sm transition-colors ${
                selectedProviders.includes(provider.id)
                  ? "border-[var(--accent-primary)] bg-[var(--accent-primary)]/10 text-[var(--accent-primary)]"
                  : "border-[var(--border-default)] bg-[var(--bg-elevated)] text-[var(--text-secondary)] hover:border-[var(--border-hover)] hover:text-[var(--text-primary)]"
              }`}
            >
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: provider.color }} />
              {provider.name}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Input Panel */}
        <div className="space-y-4">
          <div className="rounded-md border border-[var(--border-default)] bg-[var(--bg-surface)] p-5 space-y-4">
            <div>
              <label className="mb-1.5 block text-2xs font-medium uppercase tracking-wider text-[var(--text-muted)]">
                Content Type
              </label>
              <select
                value={contentType}
                onChange={(e) => setContentType(e.target.value)}
                className="w-full rounded-md border border-[var(--border-default)] bg-[var(--bg-elevated)] px-3 py-2 text-sm text-[var(--text-primary)] outline-none focus:border-[var(--accent-primary)]"
              >
                {contentTypes.map((t) => (
                  <option key={t} value={t}>{t.replace("-", " ")}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1.5 block text-2xs font-medium uppercase tracking-wider text-[var(--text-muted)]">
                Tone
              </label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="w-full rounded-md border border-[var(--border-default)] bg-[var(--bg-elevated)] px-3 py-2 text-sm text-[var(--text-primary)] outline-none focus:border-[var(--accent-primary)]"
              >
                {tones.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1.5 block text-2xs font-medium uppercase tracking-wider text-[var(--text-muted)]">
                Target Platforms
              </label>
              <div className="flex flex-wrap gap-1.5">
                {platforms.map((p) => (
                  <button
                    key={p}
                    onClick={() => togglePlatform(p)}
                    className={`rounded-md px-2.5 py-1 text-2xs transition-colors ${
                      selectedPlatforms.includes(p)
                        ? "bg-[var(--accent-primary)]/10 text-[var(--accent-primary)] border border-[var(--accent-primary)]/30"
                        : "bg-[var(--bg-elevated)] text-[var(--text-muted)] border border-[var(--border-default)] hover:text-[var(--text-secondary)]"
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-2xs font-medium uppercase tracking-wider text-[var(--text-muted)]">
                Prompt / Topic
              </label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe what you want to create..."
                className="h-28 w-full resize-none rounded-md border border-[var(--border-default)] bg-[var(--bg-elevated)] px-3 py-2 text-sm text-[var(--text-primary)] outline-none placeholder:text-[var(--text-muted)] focus:border-[var(--accent-primary)]"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-2xs font-medium uppercase tracking-wider text-[var(--text-muted)]">
                Keywords
              </label>
              <input
                type="text"
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                placeholder="AI, automation, business..."
                className="w-full rounded-md border border-[var(--border-default)] bg-[var(--bg-elevated)] px-3 py-2 text-sm text-[var(--text-primary)] outline-none placeholder:text-[var(--text-muted)] focus:border-[var(--accent-primary)]"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-2xs font-medium uppercase tracking-wider text-[var(--text-muted)]">
                Length
              </label>
              <select
                value={length}
                onChange={(e) => setLength(e.target.value)}
                className="w-full rounded-md border border-[var(--border-default)] bg-[var(--bg-elevated)] px-3 py-2 text-sm text-[var(--text-primary)] outline-none focus:border-[var(--accent-primary)]"
              >
                <option value="short">Short (50-100 words)</option>
                <option value="medium">Medium (150-300 words)</option>
                <option value="long">Long (500+ words)</option>
                <option value="custom">Custom</option>
              </select>
            </div>

            <button
              onClick={handleGenerate}
              disabled={loading || !prompt.trim() || selectedProviders.length === 0}
              className="flex w-full items-center justify-center gap-2 rounded-md bg-[var(--accent-primary)] px-4 py-2.5 text-sm font-semibold text-[var(--bg-base)] transition-opacity hover:opacity-90 disabled:opacity-40"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              {loading ? "Generating..." : "Generate Content"}
            </button>

            {error && (
              <div className="rounded-md border border-[var(--state-error)]/30 bg-[var(--state-error)]/10 px-3 py-2 text-sm text-[var(--state-error)]">
                {error}
              </div>
            )}
          </div>
        </div>

        {/* Output Panel */}
        <div className="rounded-md border border-[var(--border-default)] bg-[var(--bg-surface)] p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-medium text-[var(--text-primary)]">Generated Output</h2>
            {generated && (
              <div className="flex gap-2">
                <button className="rounded-md p-1.5 text-[var(--text-muted)] hover:bg-[var(--bg-elevated)] hover:text-[var(--text-primary)]">
                  <Copy className="h-4 w-4" />
                </button>
                <button className="rounded-md p-1.5 text-[var(--text-muted)] hover:bg-[var(--bg-elevated)] hover:text-[var(--text-primary)]">
                  <Save className="h-4 w-4" />
                </button>
                <button className="rounded-md p-1.5 text-[var(--text-muted)] hover:bg-[var(--bg-elevated)] hover:text-[var(--text-primary)]">
                  <Send className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>

          {!generated && !loading && (
            <div className="flex h-64 flex-col items-center justify-center text-[var(--text-muted)]">
              <Sparkles className="mb-3 h-8 w-8 opacity-40" />
              <p className="text-sm">Your generated content will appear here</p>
              <p className="mt-1 text-2xs">Select providers, configure settings, and hit Generate</p>
            </div>
          )}

          {loading && (
            <div className="flex h-64 flex-col items-center justify-center text-[var(--text-muted)]">
              <Loader2 className="mb-3 h-8 w-8 animate-spin" />
              <p className="text-sm">Consulting AI providers...</p>
            </div>
          )}

          {generated && (
            <div className="space-y-4">
              {Object.entries(generated).map(([provider, content]) => (
                <div key={provider} className="rounded-md border border-[var(--border-default)] bg-[var(--bg-elevated)] p-4">
                  <div className="mb-2 flex items-center gap-2">
                    <span className="text-2xs font-medium uppercase tracking-wider text-[var(--accent-primary)]">
                      {provider}
                    </span>
                  </div>
                  <div className="whitespace-pre-wrap text-sm leading-relaxed text-[var(--text-primary)]">
                    {content}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
