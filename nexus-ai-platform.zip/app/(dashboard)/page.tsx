import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { StatsCards } from "@/components/custom/stats-cards";
import { PerformanceChart } from "@/components/custom/performance-chart";
import { ProviderUsage } from "@/components/custom/provider-usage";
import { ActivityTimeline } from "@/components/custom/activity-timeline";

export default async function DashboardPage() {
  const session = await auth();
  if (!session?.user?.id) return null;

  const [contentCount, platformCount, projectCount] = await Promise.all([
    db.generatedContent.count({ where: { userId: session.user.id } }),
    db.connectedPlatform.count({ where: { userId: session.user.id, isConnected: true } }),
    db.project.count({ where: { userId: session.user.id } }),
  ]);

  return (
    <div className="space-y-6">
      <StatsCards
        contentCount={contentCount}
        platformCount={platformCount}
        projectCount={projectCount}
      />
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <PerformanceChart />
        <ProviderUsage />
      </div>
      <ActivityTimeline userId={session.user.id} />
    </div>
  );
}
