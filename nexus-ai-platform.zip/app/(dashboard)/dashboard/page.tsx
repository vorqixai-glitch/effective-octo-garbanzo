import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { formatDistanceToNow } from "date-fns";
import { TrendingUp, TrendingDown, Users, FileText, Target, Zap } from "lucide-react";

async function getStats(userId: string) {
  const [contentCount, projectCount, platformCount, recentContent] = await Promise.all([
    db.generatedContent.count({ where: { userId } }),
    db.project.count({ where: { userId } }),
    db.connectedPlatform.count({ where: { userId, isConnected: true } }),
    db.generatedContent.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 5,
      select: { id: true, type: true, prompt: true, createdAt: true },
    }),
  ]);

  return { contentCount, projectCount, platformCount, recentContent };
}

export default async function DashboardPage() {
  const session = await auth();
  const userId = session?.user?.id as string;
  const stats = await getStats(userId);

  const statCards = [
    { label: "Content Generated", value: stats.contentCount, change: "+12%", up: true, icon: FileText },
    { label: "Active Projects", value: stats.projectCount, change: "+3", up: true, icon: Target },
    { label: "Platforms Connected", value: stats.platformCount, change: "+2", up: true, icon: Users },
    { label: "AI Providers", value: 6, change: "0", up: true, icon: Zap },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-[var(--text-primary)]">Dashboard</h1>
        <p className="text-sm text-[var(--text-secondary)]">Overview of your content operations</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="rounded-md border border-[var(--border-default)] bg-[var(--bg-surface)] p-5"
            >
              <div className="flex items-center justify-between">
                <span className="text-2xs font-medium uppercase tracking-wider text-[var(--text-muted)]">
                  {stat.label}
                </span>
                <Icon className="h-4 w-4 text-[var(--text-muted)]" strokeWidth={1.5} />
              </div>
              <div className="mt-3 flex items-end justify-between">
                <span className="text-2xl font-semibold text-[var(--text-primary)]">{stat.value}</span>
                <span className={`flex items-center gap-1 text-2xs font-medium ${stat.up ? "text-[var(--state-success)]" : "text-[var(--state-error)]"}`}>
                  {stat.up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  {stat.change}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Activity */}
      <div className="rounded-md border border-[var(--border-default)] bg-[var(--bg-surface)]">
        <div className="border-b border-[var(--border-default)] px-5 py-4">
          <h2 className="text-sm font-medium text-[var(--text-primary)]">Recent Content</h2>
        </div>
        <div className="divide-y divide-[var(--border-default)]">
          {stats.recentContent.length === 0 ? (
            <div className="px-5 py-8 text-center text-sm text-[var(--text-muted)]">
              No content generated yet. Head to the AI Generator to create your first piece.
            </div>
          ) : (
            stats.recentContent.map((item) => (
              <div key={item.id} className="flex items-center justify-between px-5 py-3 hover:bg-[var(--bg-elevated)]">
                <div>
                  <p className="text-sm font-medium text-[var(--text-primary)]">{item.type.replace("-", " ")}</p>
                  <p className="text-2xs text-[var(--text-muted)]">{item.prompt.slice(0, 60)}...</p>
                </div>
                <span className="text-2xs text-[var(--text-muted)]">
                  {formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
