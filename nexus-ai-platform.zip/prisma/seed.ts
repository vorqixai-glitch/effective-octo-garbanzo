import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

async function main() {
  const hashed = await bcrypt.hash("demo123", 12);

  await db.user.upsert({
    where: { email: "demo@nexus.ai" },
    update: {},
    create: {
      email: "demo@nexus.ai",
      password: hashed,
      name: "Demo User",
    },
  });

  console.log("Seed complete — demo user created (demo@nexus.ai / demo123)");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
