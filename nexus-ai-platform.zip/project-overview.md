# NEXUS AI — Universal Content Command Center

## Overview

NEXUS AI is a unified content creation and publishing platform that integrates multiple AI providers (Claude, Kimi, Gemini, Grok, GPT, Llama) and all major social media platforms into a single mission-control interface. Users generate content using their choice of AI models, preview it across platforms, schedule posts, build ads, create videos, and publish websites — all from one dashboard.

## Goals

1. Single-dashboard content creation across all AI providers and social platforms
2. Real API integrations to AI providers and social platforms (OAuth + REST)
3. Professional, non-generic dark UI with custom design language
4. Working backend with database, auth, and API routes
5. Every button and link is functional — zero placeholders

## Core User Flow

1. User signs in via email/password or OAuth (Google)
2. User connects API keys for AI providers and social accounts
3. User selects AI providers from Orbit Rack, configures content type/tone/platforms
4. User generates content via real AI API calls
5. User previews content across platforms, edits, schedules or publishes
6. User tracks analytics across all connected platforms

## Features

### AI Content Generation
- Multi-provider Orbit Rack (Claude, Kimi, Gemini, Grok, GPT, Llama)
- 10 content types: social posts, blog articles, ad copy, emails, video scripts, website copy, product descriptions, SEO content, press releases, whitepapers
- Tone & style selection, platform targeting, keyword input
- Real-time generation with streaming responses

### Social Hub
- 10 platform connections: Instagram, Twitter/X, LinkedIn, TikTok, YouTube, Facebook, Pinterest, Threads, Snapchat, Reddit
- OAuth connection flow for each platform
- Live follower/post/engagement metrics

### Composer
- Multi-platform post composer with live previews
- Media upload and attachment
- Hashtag suggestions
- Scheduling with optimal time recommendations

### Ad Studio
- 8 ad platform configurations (Meta, Google, TikTok, LinkedIn, Twitter, YouTube, Pinterest, Snapchat)
- Campaign objectives, audience targeting, budget selection
- Live ad mockup preview with estimated metrics

### Video Studio
- Short-form and long-form video generation
- Script input, style selection, voice over options
- Background music selection
- Video preview player

### Website Builder
- Drag-and-drop component sidebar (15 components)
- Live canvas preview with browser chrome
- AI-generated complete websites from prompts
- Theme and color scheme selection
- One-click publish

### Scheduler
- Monthly calendar view with post indicators
- Upcoming posts timeline
- Optimal time recommendations

### Analytics
- Cross-platform performance metrics
- Audience demographics (age, gender, location)
- Engagement rate, CTR, conversion tracking

### Projects
- Campaign organization and management
- Project duplication and archiving
- Tag-based filtering

## Scope

### In Scope
- Full Next.js 15 App Router application
- Real backend API routes with Express/Next.js API
- SQLite database with Prisma ORM
- JWT-based authentication
- Real AI provider API integrations (user provides keys)
- Real social platform OAuth connections
- Working content generation with streaming
- All UI components functional

### Out of Scope
- Payment processing (Stripe integration placeholder)
- Real-time collaborative editing
- Mobile native app
- Advanced video rendering (ffmpeg integration placeholder)

## Success Criteria

1. A signed-in user can connect AI provider API keys and generate real content
2. A signed-in user can connect social accounts and schedule/publish posts
3. Every button in the UI triggers a real API call or state change
4. The UI passes a professional design review — no generic SaaS template look
5. The app builds and runs with `npm run dev` without errors
