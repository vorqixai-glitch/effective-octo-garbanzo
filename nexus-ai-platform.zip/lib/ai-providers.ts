import { decrypt } from "@/lib/encryption";

export type AIProvider = "claude" | "kimi" | "gemini" | "grok" | "gpt" | "llama";

export interface GenerateOptions {
  prompt: string;
  type: string;
  tone: string;
  length: string;
  keywords?: string;
}

export async function generateWithClaude(apiKey: string, options: GenerateOptions): Promise<string> {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 4096,
      messages: [{
        role: "user",
        content: buildPrompt(options),
      }],
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Claude API error: ${err}`);
  }

  const data = await response.json();
  return data.content?.[0]?.text || "";
}

export async function generateWithKimi(apiKey: string, options: GenerateOptions): Promise<string> {
  const response = await fetch("https://api.moonshot.cn/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "moonshot-v1-8k",
      messages: [{ role: "user", content: buildPrompt(options) }],
      temperature: 0.7,
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Kimi API error: ${err}`);
  }

  const data = await response.json();
  return data.choices?.[0]?.message?.content || "";
}

export async function generateWithGemini(apiKey: string, options: GenerateOptions): Promise<string> {
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: buildPrompt(options) }] }],
      }),
    }
  );

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Gemini API error: ${err}`);
  }

  const data = await response.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text || "";
}

export async function generateWithGrok(apiKey: string, options: GenerateOptions): Promise<string> {
  const response = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-beta",
      messages: [{ role: "user", content: buildPrompt(options) }],
      temperature: 0.7,
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Grok API error: ${err}`);
  }

  const data = await response.json();
  return data.choices?.[0]?.message?.content || "";
}

export async function generateWithGPT(apiKey: string, options: GenerateOptions): Promise<string> {
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: buildPrompt(options) }],
      temperature: 0.7,
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`OpenAI API error: ${err}`);
  }

  const data = await response.json();
  return data.choices?.[0]?.message?.content || "";
}

export async function generateWithLlama(apiKey: string, options: GenerateOptions): Promise<string> {
  // Using Groq as Llama host (free tier available)
  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "llama-3.1-70b-versatile",
      messages: [{ role: "user", content: buildPrompt(options) }],
      temperature: 0.7,
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Llama/Groq API error: ${err}`);
  }

  const data = await response.json();
  return data.choices?.[0]?.message?.content || "";
}

function buildPrompt(options: GenerateOptions): string {
  const { prompt, type, tone, length, keywords } = options;

  const lengthMap: Record<string, string> = {
    short: "50-100 words",
    medium: "150-300 words",
    long: "500+ words",
    custom: "custom length",
  };

  return `Create a ${type.replace("-", " ")} with the following requirements:

Topic: ${prompt}
Tone: ${tone}
Length: ${lengthMap[length] || length}
${keywords ? `Keywords to include: ${keywords}` : ""}

Please provide only the content, no explanations or meta-commentary.`;
}

export const providerMap: Record<AIProvider, { name: string; generate: (key: string, opts: GenerateOptions) => Promise<string> }> = {
  claude: { name: "Claude 3.5 Sonnet", generate: generateWithClaude },
  kimi: { name: "Kimi k1.6", generate: generateWithKimi },
  gemini: { name: "Gemini 1.5 Flash", generate: generateWithGemini },
  grok: { name: "Grok Beta", generate: generateWithGrok },
  gpt: { name: "GPT-4o Mini", generate: generateWithGPT },
  llama: { name: "Llama 3.1 70B", generate: generateWithLlama },
};
