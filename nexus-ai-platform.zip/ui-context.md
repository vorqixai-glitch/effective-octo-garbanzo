# UI Context

## Theme

Dark only. No light mode. The design language is a premium mission-control workspace — deep void blacks, layered glass surfaces with subtle depth, and a restrained accent palette. The aesthetic draws from high-end trading terminals, aerospace HUDs, and luxury automotive interfaces. No rounded pill buttons, no generic gradient cards, no pastel shadows.

## Colors

| Role              | CSS Variable         | Value       |
| ----------------- | -------------------- | ----------- |
| Page background   | `--bg-base`          | `#050507`   |
| Surface 1         | `--bg-surface`       | `#0a0a0f`   |
| Surface 2         | `--bg-elevated`      | `#111118`   |
| Surface 3         | `--bg-panel`         | `#16161f`   |
| Primary text      | `--text-primary`     | `#f0f0f5`   |
| Secondary text    | `--text-secondary`   | `#8a8a9a`   |
| Muted text        | `--text-muted`       | `#5a5a6a`   |
| Primary accent    | `--accent-primary`   | `#c8a45c`   |
| Accent glow       | `--accent-glow`      | `rgba(200,164,92,0.15)` |
| Secondary accent  | `--accent-secondary` | `#5c8aa4`   |
| Tertiary accent   | `--accent-tertiary`  | `#8a5cc8`   |
| Border default    | `--border-default`   | `rgba(255,255,255,0.06)` |
| Border hover      | `--border-hover`     | `rgba(255,255,255,0.12)` |
| Error             | `--state-error`      | `#c85c5c`   |
| Success           | `--state-success`    | `#5cc88a`   |
| Warning           | `--state-warning`    | `#c8a45c`   |

## Typography

| Role      | Font        | Weight | Size   |
| --------- | ----------- | ------ | ------ |
| Display   | Geist Sans  | 600    | 28px   |
| Heading   | Geist Sans  | 500    | 18px   |
| Body      | Geist Sans  | 400    | 14px   |
| Label     | Geist Mono  | 500    | 11px   |
| Data      | Geist Mono  | 400    | 13px   |

All text uses `letter-spacing: -0.01em` for body, `0.05em` for labels.

## Border Radius

| Context           | Value  |
| ----------------- | ------ |
| Inline / small UI | 6px    |
| Cards / panels    | 8px    |
| Modals / overlays | 12px   |
| Buttons           | 6px    |
| Inputs            | 6px    |
| Avatars           | 50%    |

No pill shapes. No excessive rounding. Sharp but refined.

## Component Library

shadcn/ui base components in `components/ui/`. Custom NEXUS components in `components/custom/`. All custom components use the design token system above.

## Layout Patterns

- **Shell**: Fixed left rail (64px), fixed top bar (52px), scrollable main area
- **Cards**: 1px border, no shadow by default, subtle lift on hover
- **Sidebars**: Fixed width, border separator, no background color difference
- **Modals**: Centered, backdrop blur, 1px border, no drop shadow
- **Tables**: Row separators only, no vertical borders, hover highlight
- **Buttons**: Solid fill for primary, ghost for secondary, no outlines

## Icons

Lucide React. Stroke width 1.5. Sizes: 14px inline, 16px buttons, 20px navigation.

## Animation

- Transitions: 150ms ease for UI, 300ms ease for page changes
- No bounce, no spring physics
- Subtle opacity and translateY for reveals
- No animated gradients or pulsing glows
