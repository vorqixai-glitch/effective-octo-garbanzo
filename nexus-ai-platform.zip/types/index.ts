export interface User {
  id: string;
  email: string;
  name?: string;
  avatar?: string;
}

export interface GeneratedContent {
  id: string;
  type: string;
  tone: string;
  platforms: string[];
  prompt: string;
  keywords?: string;
  content: string;
  providers: string[];
  length: string;
  createdAt: Date;
}

export interface ConnectedPlatform {
  id: string;
  platform: string;
  isConnected: boolean;
  followerCount?: number;
  postCount?: number;
  engagementRate?: number;
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  status: string;
  tags?: string[];
  createdAt: Date;
}

export interface ScheduledPost {
  id: string;
  platform: string;
  content: string;
  hashtags?: string;
  scheduledAt: Date;
  status: string;
}
