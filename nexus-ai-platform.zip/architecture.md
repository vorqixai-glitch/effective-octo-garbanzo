# Architecture Context

## Stack

| Layer     | Technology                  | Role                          |
| --------- | --------------------------- | ----------------------------- |
| Framework | Next.js 15 + TypeScript     | Fullstack React framework     |
| UI        | Tailwind CSS + shadcn/ui    | Utility-first CSS + components|
| Auth      | NextAuth.js (Credentials)   | JWT-based authentication      |
| Database  | Prisma + SQLite (dev)       | ORM + relational data         |
| AI APIs   | REST fetch to provider APIs | Claude, Kimi, Gemini, Grok    |
| Social    | OAuth 2.0 + REST APIs       | Platform posting & analytics  |
| State     | React Context + Hooks       | Client-side state management  |
| Fonts     | Geist Sans + Geist Mono     | Typography system             |

## System Boundaries

- `app/` — Next.js App Router pages and API routes
- `components/ui/` — shadcn/ui base components (generated, protected)
- `components/custom/` — NEXUS-specific components
- `lib/` — Utility functions, API clients, auth config
- `prisma/` — Database schema and migrations
- `hooks/` — Custom React hooks for data fetching
- `types/` — TypeScript type definitions

## Storage Model

- **SQLite (Prisma)**: Users, API keys, connected platforms, projects, generated content, scheduled posts, analytics snapshots
- **File system**: Temporary uploaded media, generated video previews
- **External APIs**: AI provider responses, social platform data

## Auth and Access Model

- Users sign in via email/password (NextAuth Credentials provider)
- JWT tokens stored in httpOnly cookies
- Each user owns their API keys, projects, and scheduled posts
- API keys are encrypted at rest using AES-256

## Invariants

1. API routes validate auth before any data access
2. External API keys never leak to the client
3. Request handlers do not run long-lived background work
4. All database mutations go through Prisma
5. No hardcoded hex values — all colors via CSS custom properties
